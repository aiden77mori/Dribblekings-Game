Installing the plugin on Construct2:
1.Copy folder idnet to <install path>\exporters\html5\plugins
2.Start or restart Construct2

Available functions:
Is authorized - Return true if sdk is loaded
Is not authorized - Return true if sdk is not loade
Init - Initialisation of Idnet with appId param
Show registration box - Show a dialog prompting the user to register an account
Show login box - Show a dialog prompting the user to login an account
Submit statistic - Submit a scores to the IDNet statistics system.
Show leaderboard - Show leaderboard popup
User name - Return the current user's name, or a guest name if not logged in.
Session Key - SessionKey", "Return session key

