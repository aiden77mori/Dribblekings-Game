# id.net Construct2 Plugin

To use this plugin, make a folder in your plugin directory called idnet.

Then download the zip archive from Github and extract the files into the idnet folder.

More instructions, can be found at the following link.
https://www.scirra.com/manual/158/third-party-addons
